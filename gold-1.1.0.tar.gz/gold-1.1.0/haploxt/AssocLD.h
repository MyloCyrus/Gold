////////////////////////////////////////////////////////////////////// 
// haploxt/AssocLD.h 
// (c) 2000-2001 Goncalo Abecasis
// 
// This file is distributed as part of the GOLD source code package   
// and may not be redistributed in any form, without prior written    
// permission from the author. Permission is granted for you to       
// modify this file for your own personal use, but modified versions  
// must retain this copyright notice and must not be distributed.     
// 
// Permission is granted for you to use this file to compile GOLD.    
// 
// All computer programs have bugs. Use this file at your own risk.   
// 
// Thursday November 08, 2001
// 
 
#ifndef __ASSOC_LD__
#define __ASSOC_LD__

class AssocLD
   {
   public :
      double D;
      double Dmax;
      double standardD;

      int    isValid;

      AssocLD() { isValid = 0; }

      void Calc(int ** nn, int ni, int nj);
   };

#endif 
