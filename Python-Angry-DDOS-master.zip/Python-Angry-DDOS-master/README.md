# Python-Angry-DDOS

Python-Angry-DDOS

This is a Powerful Tool for Pentesters to have a fast DDOS Attack .I Write This app With Python Programming Language

It's a CLI app , You Just Run The App & Enter The Target IP & BOOOM ! Your Attack Is Starting ...

I Hope You Enjoy Of That !

# Developer : Mohammad babaee
